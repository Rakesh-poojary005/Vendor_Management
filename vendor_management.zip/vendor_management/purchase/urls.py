
from django.urls import path
from .views import (
    PurchaseOrderListCreateView,
    PurchaseOrderRetrieveUpdateDeleteView,
    AcknowledgePurchaseOrderView,
)

urlpatterns = [

    # Purchase Order URLs
    path('api/purchase_orders/', PurchaseOrderListCreateView.as_view(), name='purchase-order-list-create'),
    path('api/purchase_orders/<int:pk>/', PurchaseOrderRetrieveUpdateDeleteView.as_view(), name='purchase-order-retrieve-update-delete'),
    path('api/purchase_orders/<int:pk>/acknowledge/', AcknowledgePurchaseOrderView.as_view(), name='acknowledge-purchase-order'),

]
