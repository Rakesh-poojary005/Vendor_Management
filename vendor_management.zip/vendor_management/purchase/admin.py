from django.contrib import admin
from vendor.models import Vendor, HistoricalPerformance
from purchase.models import PurchaseOrder

# Register your models here.
admin.site.register(Vendor)
admin.site.register(HistoricalPerformance)
admin.site.register(PurchaseOrder)
